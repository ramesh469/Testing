package bcccp.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bcccp.carpark.Carpark;


public class TestCarPark {

	static Carpark carPark;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		Carpark.class.getClass();
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void register() {
		
	}
	@Test
	public void deregister() {
		
	}
	@Test
	public void getName() {
		
	}
	@Test
	public void isFull() {
		
	}
	@Test
	public void issueAdhocTicket() {
		
	}
	@Test
	public void recordAdhocTicketEntry() {
		
	}
	@Test
	public void getAdhocTicket() {
		
	}
	@Test
	public void calculateAddHocTicketCharge() {
		
	}
	@Test
	public void recordAdhocTicketExit() {
		
	}
	@Test
	public void registerSeasonTicket() {
		
	}
	@Test
	public void deregisterSeasonTicket() {
		
	}
	@Test
	public void isSeasonTicketValid() {
		
	}
	@Test
	public void isSeasonTicketInUse() {
		
	}
	@Test
	public void recordSeasonTicketEntry() {
		
	}
	@Test
	public void recordSeasonTicketExit() {
		
	}


}
