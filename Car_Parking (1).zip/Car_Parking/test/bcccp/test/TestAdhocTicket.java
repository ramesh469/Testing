package bcccp.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bcccp.tickets.adhoc.AdhocTicket;

public class TestAdhocTicket {
	static AdhocTicket adhocTicket;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		AdhocTicket.class.getClass();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void getTicketNo() {
		
	}
	@Test
	public void getBarcode() {
		
	}
	@Test
	public void getCarparkId() {
		
	}
	@Test
	public void ticketInserted() {
		
	}
	@Test
	public void getEntryDateTime() {
		
	}
	@Test
	public void isCurrent() {
		
	}
	@Test
	public void pay() {
		
	}
	@Test
	public void getPaidDateTime() {
		
	}
	@Test
	public void isPaid() {
		
	}
	@Test
	public void getCharge() {
		
	}
	@Test
	public void exit() {
		
	}
	@Test
	public void getExitDateTime() {
		
	}
	@Test
	public void hasExited() {
		
	}


}
