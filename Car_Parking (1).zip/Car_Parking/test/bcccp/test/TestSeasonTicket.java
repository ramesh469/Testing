package bcccp.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bcccp.tickets.season.SeasonTicket;

public class TestSeasonTicket {

	static SeasonTicket seasonTicket;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		SeasonTicket.class.getClass();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void getId() {
		
	}
	@Test
	public void getCarparkId() {
		
	}
	@Test
	public void getStartValidPeriod() {
		
	}
	@Test
	public void getEndValidPeriod() {
		
	}
	@Test
	public void inUse() {
		
	}
	@Test
	public void recordUsage() {
		
	}
	@Test
	public void getCurrentUsageRecord() {
		
	}
	@Test
	public void endUsage() {
		
	}
	@Test
	public void getUsageRecords() {
		
	}
	@Test
	public void getCharge() {
		
	}
	@Test
	public void exit() {
		
	}
	@Test
	public void getExitDateTime() {
		
	}
	@Test
	public void hasExited() {
		
	}
}
