package bcccp.carpark.exit;

public interface IExitController {
	public void ticketInserted(String ticketStr);
	public void ticketTaken();

}
