package bcccp.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bcccp.tickets.adhoc.AdhocTicketDAO;

public class TestAdhocTicketDAO {

	static AdhocTicketDAO adhocTicketDAO;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		AdhocTicketDAO.class.getClass();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void AdhocTicketDAO() {
		
	}
	@Test
	public void createTicket() {
		
	}
	@Test
	public void findTicketByBarcode() {
		
	}
	@Test
	public void getCurrentTickets() {
	}
}
